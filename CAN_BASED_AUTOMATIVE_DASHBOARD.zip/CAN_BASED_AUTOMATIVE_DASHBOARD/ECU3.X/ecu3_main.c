/*
 * File:   ecu3_main.c
 * Author: Manda
 *
 * Created on 2 May, 2026, 1:24 PM
 */


#include "ecu3_sensor.h"
#include "can.h"
#include "clcd.h"
#include "msg_id.h"
#include "tmr0.h"

    void init_config(void) {
        // Initialize CLCD and CANBUS
        init_clcd();
        TRISB = 0x08; // Set RB2 as output, RB3 as input, remaining as output for can
        PORTB = 0x00;
        init_can();
        // Enable Interrupts
        PEIE = 1;
        GIE = 1;
        init_timer0();
    }

    void main(void)
    {
        // Initialize peripherals
        init_config();
         clcd_print("SPD", LINE1(5));        
         clcd_print("GR", LINE1(9)); 
         clcd_print("RPM", LINE1(0));   
         clcd_print("IND", LINE1(12));  
        /* ECU3 main loop */
        while (1)
        {
            // Read CAN Bus
            process_canbus_data();
        }

        return;
    }
