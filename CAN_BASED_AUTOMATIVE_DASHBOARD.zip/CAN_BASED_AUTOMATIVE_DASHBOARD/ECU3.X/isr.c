/*
 * File:   isr.c
 * Author: Manda
 *
 * Created on 10 May, 2026, 1:16 PM
 */


#include <xc.h>
#include "ecu3_sensor.h"

void __interrupt() isr(void)
{
	static unsigned short count;
     
	if (TMR0IF)
	{
		TMR0 = TMR0 + 8;

		if (++count >= 5000)
		{
			count = 0;
            led_state ^= 1;
		}
		TMR0IF = 0;
	}
}
