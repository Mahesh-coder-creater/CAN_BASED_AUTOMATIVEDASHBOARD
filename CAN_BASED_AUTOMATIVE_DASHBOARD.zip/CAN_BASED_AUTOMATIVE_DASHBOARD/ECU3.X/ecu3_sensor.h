/* 
 * File:   ecu3_main.h
 * Author: Manda
 *
 * Created on 2 May, 2026, 1:23 PM
 */

#ifndef ECU3_SENSOR_H
#define	ECU3_SENSOR_H

#include <stdint.h>
#include <xc.h>
#define _XTAL_FREQ 20000000

#define RPM_ADC_CHANNEL 0x04
#define ENG_TEMP_ADC_CHANNEL 0x06

#define OFF 0
#define ON 1

#define RIGHT_IND_ON() (PORTB = PORTB | 0xC0)
#define RIGHT_IND_OFF() (PORTB = PORTB & ~0xC0)
#define LEFT_IND_ON() (PORTB = PORTB | 0x03)
#define LEFT_IND_OFF() (PORTB = PORTB & ~0x03)

typedef enum {
    e_ind_off,
    e_ind_left,
    e_ind_right,
    e_ind_hazard
} IndicatorStatus;

typedef enum
{
    GEAR_NEUTRAL = 0,
    GEAR_1,
    GEAR_2,
    GEAR_3,
    GEAR_4,
    GEAR_5,
    GEAR_REVERSE
} GearState;

extern volatile unsigned char led_state;

void process_canbus_data();
void handle_speed_data(uint8_t *data, uint8_t len);
void handle_gear_data(uint8_t *data, uint8_t len);
void handle_rpm_data(uint8_t *data, uint8_t len);
void handle_engine_temp_data(uint8_t *data, uint8_t len);
void handle_indicator_data(uint8_t *data, uint8_t len);

#endif	/* ECU1_SENSOR_H */


