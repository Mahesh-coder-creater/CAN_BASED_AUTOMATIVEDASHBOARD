/*
 * File:   ecu3_sensor.c
 * Author: Manda
 *
 * Created on 10 May, 2026, 1:15 PM
 */


#include "ecu3_sensor.h"
#include "msg_id.h"
#include "can.h"
#include "clcd.h"
#include <string.h>
volatile unsigned char led_state = e_ind_off; // LED blink state for indicators

/* Handle received speed data */
void handle_speed_data(uint8_t *data, uint8_t len)
{
    char buf[4];                         // Buffer to store speed string

    memcpy(buf, data, 3);              // Copy received CAN data
    buf[3] = '\0';    
    // clcd_print("  ",LINE2(5)); // Null terminate string
    clcd_print(buf, LINE2(5));            // Display speed value
}

/* Handle received gear data */
void handle_gear_data(uint8_t *data, uint8_t len) 
{
    char gear_str[3];                    // Buffer for gear display

    // Decode gear value
    switch (data[0])
    {
        case GEAR_NEUTRAL:  gear_str[0] = 'N'; gear_str[1] = ' '; break;
        case GEAR_1:        gear_str[0] = 'G'; gear_str[1] = '1'; break;
        case GEAR_2:        gear_str[0] = 'G'; gear_str[1] = '2'; break;
        case GEAR_3:        gear_str[0] = 'G'; gear_str[1] = '3'; break;
        case GEAR_4:        gear_str[0] = 'G'; gear_str[1] = '4'; break;
        case GEAR_5:        gear_str[0] = 'G'; gear_str[1] = '5'; break;
        case GEAR_REVERSE:  gear_str[0] = 'R'; gear_str[1] = ' '; break;
        default:            gear_str[0] = '-'; gear_str[1] = '-'; break;
    }

    gear_str[2] = '\0';                  // Null terminate string
    clcd_print("  ",LINE2(5));
    clcd_print(gear_str, LINE2(9));       // Display gear value
}

/* Handle received RPM data */
void handle_rpm_data(uint8_t *data, uint8_t len) 
{
    char buf[8];                         // Buffer to store RPM string

    memcpy(buf, data, len);              // Copy received CAN data
    buf[len] = '\0';                     // Null terminate string
    clcd_print(buf, LINE2(0));            // Display RPM value
}

/* Handle received indicator data */
void handle_indicator_data(uint8_t *data, uint8_t len)
{
    switch(data[0])
    {
        case e_ind_left:

            if(led_state)
            {
                LEFT_IND_ON();
                RIGHT_IND_OFF();
                clcd_print("<-", LINE2(12));
            }
            else
            {
                LEFT_IND_OFF();
                RIGHT_IND_OFF();
                clcd_print("  ", LINE2(12));
            }
            break;

        case e_ind_right:

            if(led_state)
            {
                RIGHT_IND_ON();
                LEFT_IND_OFF();
                clcd_print("->", LINE2(12));
            }
            else
            {
                RIGHT_IND_OFF();
                LEFT_IND_OFF();
                clcd_print("  ", LINE2(12));
            }
            break;

        case e_ind_hazard:

            if(led_state)
            {
                LEFT_IND_ON();
                RIGHT_IND_ON();
                clcd_print("<>", LINE2(12));
            }
            else
            {
                LEFT_IND_OFF();
                RIGHT_IND_OFF();
                clcd_print("  ", LINE2(12));
            }
            break;

        default:

            LEFT_IND_OFF();
            RIGHT_IND_OFF();
            clcd_print("--", LINE2(12));
            break;
    }
}

/* Process received CAN bus data */
void process_canbus_data() 
{   
    uint8_t rx_data[8];                  // CAN receive buffer
    uint16_t rx_id;                      // Received CAN message ID
    uint8_t rx_len;                      // Length of received data

    can_receive(&rx_id, rx_data, &rx_len); // Receive CAN message
    if(rx_len == 0)
    {
        return;
    }
    switch (rx_id)
    {
        case SPEED_MSG_ID:      
            handle_speed_data(rx_data, rx_len);
            break;
        case GEAR_MSG_ID:       
            handle_gear_data(rx_data, rx_len);
            break;
        case RPM_MSG_ID:        
            handle_rpm_data(rx_data, rx_len); 
            break;
        case INDICATOR_MSG_ID:  
            handle_indicator_data(rx_data, rx_len);
            break;
//        default:
//    {
//        char buf[10];
//
//        sprintf(buf,"%X",rx_id);
//
//        clcd_print(buf, LINE2(0));
//    }
    }
    
}
