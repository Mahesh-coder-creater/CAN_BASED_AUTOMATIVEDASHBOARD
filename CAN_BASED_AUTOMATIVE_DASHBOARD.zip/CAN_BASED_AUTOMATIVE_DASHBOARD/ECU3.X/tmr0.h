/* 
 * File:   tmr0.h
 * Author: Manda
 *
 * Created on 10 May, 2026, 1:11 PM
 */

#ifndef TIMER0_H
#define TIMER0_H

void init_timer0(void);

#endif

