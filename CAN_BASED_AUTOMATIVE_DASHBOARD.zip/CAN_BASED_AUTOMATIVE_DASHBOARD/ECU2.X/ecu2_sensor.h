/* 
 * File:   ecu2_sensor.h
 * Author: Manda
 *
 * Created on 12 May, 2026, 5:46 PM
 */

#ifndef ECU2_SENSOR_H
#define	ECU2_SENSOR_H

#include <stdint.h>
#include "dkp.h"
#include <xc.h>

#define RPM_ADC_CHANNEL 0x04
#define ENG_TEMP_ADC_CHANNEL 0x06

#define OFF 0
#define ON 1

#define RIGHT_IND_ON() (PORTB = PORTB | 0xC0)
#define RIGHT_IND_OFF() (PORTB = PORTB & ~0xC0)
#define LEFT_IND_ON() (PORTB = PORTB | 0x03)
#define LEFT_IND_OFF() (PORTB = PORTB & ~0x03)

typedef enum {
    e_ind_off,
    e_ind_left,
    e_ind_right,
    e_ind_hazard
} IndicatorStatus;


extern volatile unsigned char led_state;

unsigned short get_rpm(void);
IndicatorStatus process_indicator(void);

#endif	/* ECU1_SENSOR_H */


