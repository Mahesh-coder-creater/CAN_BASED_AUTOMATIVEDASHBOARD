/* 
 * File:   dkp.h
 * Author: Manda
 *
 * Created on 12 May, 2026, 5:45 PM
 */

#ifndef DKP_H
#define DKP_H

#define SW1 0x0E
#define SW2 0x0D
#define SW3 0x0B
#define SW4 0x07

#define ON				1
#define OFF				0

void init_dkp(void);
char read_dkp(int);

#endif

