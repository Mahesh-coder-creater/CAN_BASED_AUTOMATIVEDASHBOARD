/*
 * File:   ecu2_main.c
 * Author: Manda
 *
 * Created on 12 May, 2026, 5:53 PM
 */


#include "ecu2_sensor.h"     // ECU2 sensor-related functions
#include "adc.h"             // ADC driver for RPM sensing
#include "can.h"             // CAN communication driver
#include "msg_id.h"          // CAN message ID definitions
#include "dkp.h"             // Digital keypad driver

#define _XTAL_FREQ 20000000  // System clock frequency (20 MHz)

/* Initialize all required peripherals */
void init_config()
{
    init_adc();              // Initialize ADC module
    init_can();              // Initialize CAN module
    init_dkp();              // Initialize digital keypad
}

void main(void)
{
    init_config();           // Call initialization routine

    unsigned short rpm;      // Variable to store RPM value
    IndicatorStatus ind_status; // Variable to store indicator status

    unsigned char tx_data_1[4]; // CAN transmit buffer for RPM
    unsigned char tx_data_2[1]; // CAN transmit buffer for indicator

    while (1)
    {
        /* ------------ TRANSMIT DATA ------------ */

        rpm = get_rpm();             // Read RPM from sensor using ADC
        ind_status = process_indicator(); // Read and process indicator status

        /* Convert RPM value into ASCII characters */
        tx_data_1[0] = rpm / 1000 + '0';        // Thousands place
        tx_data_1[1] = (rpm / 100) % 10 + '0';  // Hundreds place
        tx_data_1[2] = (rpm / 10) % 10 + '0';   // Tens place
        tx_data_1[3] = rpm % 10 + '0';          // Units place
        
        /* Store indicator status */
        tx_data_2[0] = (uint8_t)ind_status;   // Indicator ON/OFF status
        
        /* Transmit data over CAN bus */
        can_transmit(RPM_MSG_ID, tx_data_1, 4);       // Send RPM data to ECU3
        can_transmit(INDICATOR_MSG_ID, tx_data_2, 1); // Send indicator data to ECU3
    }
}
