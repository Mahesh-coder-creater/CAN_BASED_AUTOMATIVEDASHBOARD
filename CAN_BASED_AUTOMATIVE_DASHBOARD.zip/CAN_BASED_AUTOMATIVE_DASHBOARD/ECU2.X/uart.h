/* 
 * File:   uart.h
 * Author: Manda
 *
 * Created on 12 May, 2026, 5:48 PM
 */

#ifndef UART_H
#define	UART_H

void init_uart();
void putch(unsigned char data);
void puts(unsigned char *data);
unsigned char getch();

#endif	/* UART_H */

