/*
 * File:   uart.c
 * Author: Manda
 *
 * Created on 12 May, 2026, 5:54 PM
 */


#include <xc.h>

void init_uart()
{
    
    
    TX9=0;
    TXEN=1;
    SYNC=0;
    BRGH=1;
    
    SPEN=1;
    RX9=0;
    CREN=1;
    
    
    BRG16=0;
    SPBRG=10; //SETTING BAUD RATE 115200
    TXIF=0;
    RCIF=0;
    SENDB=0;
}
void putch(unsigned char data)
{
     while(!TXIF);
     TXIF=0;
    TXREG=data;
   
}
void puts(unsigned char *data)
{
    while(*data)
    {
        putch(*data);
        data++;
    }
}
unsigned char getch()
{
    while(!RCIF);
    RCIF=0;
    return RCREG;
}

