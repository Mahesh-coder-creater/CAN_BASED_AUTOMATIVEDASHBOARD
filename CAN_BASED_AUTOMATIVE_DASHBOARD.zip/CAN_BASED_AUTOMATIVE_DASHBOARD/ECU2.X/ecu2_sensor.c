/*
 * File:   ecu2_sensor.c
 * Author: Manda
 *
 * Created on 12 May, 2026, 5:53 PM
 */


#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "dkp.h"

/* Function to calculate RPM using ADC value */
unsigned short get_rpm()
{
    unsigned short rpm = 0;  // Variable to store calculated RPM

    // Read ADC value from RPM channel and convert to RPM
    rpm = (read_adc(RPM_ADC_CHANNEL) * 50) / 10.23;

    return rpm;              // Return RPM value
}

/* Function to process indicator key input */
IndicatorStatus process_indicator()
{
    static char last_key = 0x0F; // Store last valid key (default: no key)
    char key;                    // Variable to store current key

    key = read_dkp(0);           // Read digital keypad input

    // Update last key only if a valid key is pressed
    if (key != 0x0F)
        last_key = key;

    // Determine indicator status based on last pressed key
    switch (last_key)
    {
        case SW1: return e_ind_left;    // Left indicator
        case SW2: return e_ind_right;   // Right indicator
        case SW3: return e_ind_hazard;  // Hazard indicator
        case SW4: return e_ind_off;     // Indicator OFF
        default:  return e_ind_off;     // Default state
    }
}