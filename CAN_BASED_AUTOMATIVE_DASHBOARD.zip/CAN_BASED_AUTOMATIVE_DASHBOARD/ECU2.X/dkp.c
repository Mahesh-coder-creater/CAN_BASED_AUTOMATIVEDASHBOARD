/*
 * File:   dkp.c
 * Author: Manda
 *
 * Created on 12 May, 2026, 5:49 PM
 */


#include <xc.h>
#include "dkp.h"
void init_dkp(void)
{
    TRISC = TRISC | 0X0F;
}

char read_dkp(int choice)
{
    if(choice == 1)
    {
        return PORTC & 0x0F;
    }
    else if(choice == 0)
    {
        static int count = 0;
        if(((PORTC & 0x0F) != 0x0F) && count == 0)
        {
            count = 1;
            return PORTC & 0x0F;
        }
        else if((PORTC & 0x0F) == 0x0F)
        {
            count = 0;
        }
    }
    return 0x0F;
}
