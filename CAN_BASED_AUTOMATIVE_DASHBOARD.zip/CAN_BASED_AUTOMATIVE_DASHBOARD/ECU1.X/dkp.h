/* 
 * File:   digital_keypad.h
 * Author: Manda
 *
 * Created on 29 April, 2026, 11:29 AM
 */



#ifndef DKP_H
#define DKP_H

#define SW1 0x0E
#define SW2 0x0D
#define SW3 0x0B
#define SW4 0x07

#define ON				1
#define OFF				0

void init_dkp(void);
char read_dkp(int);

#endif

