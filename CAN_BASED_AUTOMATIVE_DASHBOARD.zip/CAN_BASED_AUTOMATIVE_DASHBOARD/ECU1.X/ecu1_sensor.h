/* 
 * File:   ecu1_sensor.h
 * Author: Manda
 *
 * Created on 11 May, 2026, 3:26 PM
 */


#ifndef ECU1_SENSOR_H
#define	ECU1_SENSOR_H

#include <stdint.h>
#include "dkp.h"
#include <xc.h>

#define RPM_ADC_CHANNEL 0x04
#define ENG_TEMP_ADC_CHANNEL 0x06

#define OFF 0
#define ON 1

typedef enum
{
    GEAR_NEUTRAL = 0,
    GEAR_1,
    GEAR_2,
    GEAR_3,
    GEAR_4,
    GEAR_5,
    GEAR_REVERSE
} GearState;


extern volatile unsigned char led_state;

unsigned short get_speed(void);
GearState get_gear(void);

#endif
