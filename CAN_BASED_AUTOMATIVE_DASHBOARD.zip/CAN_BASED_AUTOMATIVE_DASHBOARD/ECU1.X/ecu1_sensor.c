/*
 * File:   ecu1_sensor.c
 * Author: Manda
 *
 * Created on 29 April, 2026, 11:26 AM
 */



#include "ecu1_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "dkp.h"

/* Function to calculate vehicle speed using ADC value */
unsigned short get_speed()
{
    unsigned short speed = 0;          // Variable to store speed value

    // Read ADC value and scale it to speed range
    speed = (read_adc(RPM_ADC_CHANNEL) / 10.23);

    return speed;                      // Return calculated speed
}

/* Function to get current gear state using keypad input */
GearState get_gear()
{
    static GearState gear = GEAR_NEUTRAL; // Store last gear state
    char key;                             // Variable to store key input

    key = read_dkp(0);                    // Read keypad input

    // Increase gear when SW1 is pressed
    if (key == SW1)                      // Gear up
    {
        if (gear < GEAR_REVERSE)         // Check upper gear limit
            gear++;                      // Increment gear
    }
    // Decrease gear when SW2 is pressed
    else if (key == SW2)                 // Gear down
    {
        if (gear > GEAR_NEUTRAL)         // Check lower gear limit
            gear--;                      // Decrement gear
    }
//    else if(key==SW3)
//    {
//   
//    }
//    else if(key==SW4)
//    {
//        
//    }

    return gear;                         // Return current gear state
}