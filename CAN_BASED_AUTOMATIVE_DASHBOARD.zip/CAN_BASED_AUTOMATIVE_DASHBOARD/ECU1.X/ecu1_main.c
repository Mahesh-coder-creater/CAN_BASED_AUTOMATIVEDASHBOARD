/*
 * File:   ecu1_main.c
 * Author: Manda
 *
 * Created on 29 April, 2026, 11:26 AM
 */


#include "ecu1_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "dkp.h"
//#define _XTAL_FREQ 20000000

/* Initialize all required peripherals */
void init_config()
{
    init_adc();          // Initialize ADC for speed sensing
    init_can();          // Initialize CAN module
    init_dkp();          // Initialize digital keypad for gear input
}

void main(void)
{
    init_config();       // Call initialization function
    
    unsigned short speed_value; // Variable to store speed value
    GearState gear_status;      // Variable to store gear status

    unsigned char tx_data_1[3]; // CAN transmit buffer for speed
    unsigned char tx_data_2[1]; // CAN transmit buffer for gear

    while (1)
    {
        /* --------- TRANSMIT SECTION --------- */

        speed_value = get_speed(); // Read vehicle speed
        gear_status = get_gear();  // Read current gear position

        /* Convert speed value 
         * 
         * to ASCII characters */
        tx_data_1[0] = speed_value / 100 + '0';        // Hundreds place
        tx_data_1[1] = (speed_value / 10) % 10 + '0';  // Tens place
        tx_data_1[2] = speed_value % 10 + '0';         // Units place
        
        /* Store gear status */
        tx_data_2[0] = gear_status; // Gear value
        
        /* Transmit data over CAN bus */
        can_transmit(SPEED_MSG_ID, tx_data_1, 3); // Send speed data to ECU3
        can_transmit(GEAR_MSG_ID, tx_data_2, 1);  // Send gear data to ECU3
    }
}



